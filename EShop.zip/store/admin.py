from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order

class adminProduct(admin.ModelAdmin):
    list_display=['name','price','category']

class adminCategory(admin.ModelAdmin):
    list_display=['name']

class adminCustomer(admin.ModelAdmin):
    list_display=['first_name','last_name','phone','email','password']

# Register your models here.
admin.site.register(Product,adminProduct)
admin.site.register(Category,adminCategory)
admin.site.register(Customer,adminCustomer)
admin.site.register(Order)