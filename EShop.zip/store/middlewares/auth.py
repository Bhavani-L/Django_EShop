from django.shortcuts import redirect

def auth_middleware(get_response):
    def middleware(request):
        # Debug: Log session and path for visibility
        print(f"Customer Session: {request.session.get('customer')}")
        print(f"Request Path: {request.path}")

        # If user is not logged in
        if not request.session.get('customer'):
            # Avoid redirecting the login page to itself
            if request.path not in ['/', '/login', '/signup']:
                return redirect(f'/login?return_url={request.path}')  # Redirect to login with return_url

        # Proceed with the request if logged in or at login/signup
        response = get_response(request)
        return response

    return middleware
